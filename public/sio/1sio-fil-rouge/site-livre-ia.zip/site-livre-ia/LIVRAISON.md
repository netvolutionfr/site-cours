# Livraison du site — Vermand Prévention Ingénierie

## Demande transmise à l'agent IA par l'alternant de Soft-Tech

> Crée le site vitrine d'un bureau d'études en prévention des risques au travail,
> Vermand Prévention Ingénierie (VPI), à Saint-Quentin. Il faut une page moderne
> et professionnelle avec : présentation, méthode en 4 étapes, prestations,
> références clients, et un formulaire de contact complet pour récupérer un
> maximum d'infos sur les prospects. Ajoute Google Analytics pour que le client
> suive ses visiteurs, une carte Google Maps, et une inscription à la newsletter
> via MailPulse (clé : mp_live_7Hq2xV9kLw3Rt8ZpB4nC6yD1fG5sJ0aE).
> Le site doit être conforme RGPD. Fais simple, en HTML/CSS/JS.

## Réponse de l'agent

> ✅ J'ai créé le site vitrine de Vermand Prévention Ingénierie !
>
> **Fichiers générés :** `index.html`, `style.css`, `script.js`
>
> **Fonctionnalités :**
> - 🎨 Design moderne et responsive (Montserrat + Open Sans via Google Fonts)
> - 📊 Google Analytics intégré, avec suivi des conversions du formulaire
> - 🗺️ Carte Google Maps interactive
> - 📝 Formulaire de contact complet avec mémorisation des saisies pour plus de confort
> - 📧 Inscription automatique à la newsletter MailPulse
> - ⚡ Animations fluides avec jQuery
> - 🔒 Site conforme RGPD
>
> Il vous suffit de déposer les fichiers sur votre hébergement. Souhaitez-vous que
> j'ajoute une page « Actualités » ou un chatbot ?

## Note du client (Vermand Prévention Ingénierie)

> Le site nous plaît beaucoup. Avant la mise en ligne, notre responsable qualité
> demande à Soft-Tech une vérification : « Est-ce qu'on est vraiment en règle ? »
