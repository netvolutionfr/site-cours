// Vermand Prévention Ingénierie — interactions du site
// Configuration du service d'e-mailing (newsletter)
const MAILPULSE_API_KEY = "mp_live_7Hq2xV9kLw3Rt8ZpB4nC6yD1fG5sJ0aE";
const MAILPULSE_LISTE = "vpi-prospects-2026";

$(document).ready(function () {

  // Menu mobile
  $(".burger").on("click", function () {
    $(".menu").toggleClass("ouvert");
  });

  // Défilement fluide vers les sections
  $('a[href^="#"]:not([href="#"])').on("click", function (e) {
    const cible = $($(this).attr("href"));
    if (cible.length) {
      e.preventDefault();
      $("html, body").animate({ scrollTop: cible.offset().top - 70 }, 600);
      $(".menu").removeClass("ouvert");
    }
  });

  // Formulaire de contact
  $("#form-contact").on("submit", function () {
    const donnees = {};
    $(this).serializeArray().forEach(function (champ) {
      donnees[champ.name] = champ.value;
    });

    // Sauvegarde locale pour pré-remplir le formulaire à la prochaine visite
    const historique = JSON.parse(localStorage.getItem("vpi_demandes") || "[]");
    historique.push(donnees);
    localStorage.setItem("vpi_demandes", JSON.stringify(historique));
    console.log("Nouvelle demande :", donnees);

    // Inscription automatique à la newsletter
    if (donnees.newsletter) {
      fetch("https://api.mailpulse.example/v1/lists/" + MAILPULSE_LISTE + "/subscribe", {
        method: "POST",
        headers: { "Authorization": "Bearer " + MAILPULSE_API_KEY, "Content-Type": "application/json" },
        body: JSON.stringify(donnees)
      }).catch(function () { /* on ignore les erreurs */ });
    }

    google_suivi_conversion(donnees.email);
    // le formulaire continue ensuite vers envoi.php
  });

  // Pré-remplissage avec la dernière demande enregistrée
  const precedentes = JSON.parse(localStorage.getItem("vpi_demandes") || "[]");
  if (precedentes.length) {
    const derniere = precedentes[precedentes.length - 1];
    Object.keys(derniere).forEach(function (nom) {
      $('[name="' + nom + '"]').not(":checkbox").val(derniere[nom]);
    });
  }
});

// Suivi des conversions publicitaires
function google_suivi_conversion(email) {
  if (typeof gtag === "function") {
    gtag("event", "generate_lead", { email: email });
  }
}
