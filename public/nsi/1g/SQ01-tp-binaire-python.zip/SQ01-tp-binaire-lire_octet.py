# Première NSI — lundi 12 octobre 2026
# 5. Lire un octet avec Python
# La machine reçoit huit bits sous forme de texte, par exemple "01001101". Complétez les deux ... de lire_octet(bits), sans int(bits, 2). Le paramètre contient exactement huit caractères 0 ou 1. La fonction renvoie un entier. bits[0] est le caractère de gauche, de poids 128. Chaque tour lit une position, puis divise le poids par 2.
# Avant de lancer : prévoir le résultat ; après : expliquer une correction.
# Remplacez les ... ; ne modifiez pas les tests.

def lire_octet(bits):
    total = 0
    poids = 128
    for bit in bits:
        if bit == "1":
            total = ...
        poids = ...
    return total


print(lire_octet("01001101"))

# Tests : un assert silencieux a réussi.
assert lire_octet("00000000") == 0
assert lire_octet("00000001") == 1
assert lire_octet("00000010") == 2
assert lire_octet("00000100") == 4
assert lire_octet("00001000") == 8
assert lire_octet("00010000") == 16
assert lire_octet("00100000") == 32
assert lire_octet("01000000") == 64
assert lire_octet("10000000") == 128
assert lire_octet("01001101") == 77
assert lire_octet("10101100") == 172
assert lire_octet("11111111") == 255
print("Tous les tests passent.")
