# Première NSI — lundi 12 octobre 2026
# 4. Programmer les poids
# Pour afficher les étiquettes de votre machine, complétez poids(position). La position 0 est celle de droite ; les positions admises vont de 0 à 7. Utilisez ** pour une puissance. La fonction doit renvoyer un entier.
# Avant de lancer : prévoir le résultat ; après : expliquer une correction.
# Remplacez les ... ; ne modifiez pas les tests.

def poids(position):
    return ...


for position in range(8):
    print(position, poids(position))

# Tests : un assert silencieux a réussi.
assert poids(0) == 1
assert poids(1) == 2
assert poids(2) == 4
assert poids(3) == 8
assert poids(4) == 16
assert poids(5) == 32
assert poids(6) == 64
assert poids(7) == 128
print("Tous les tests passent.")
