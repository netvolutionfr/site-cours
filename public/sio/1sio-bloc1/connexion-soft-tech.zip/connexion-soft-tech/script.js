// Étape 3 : faire fonctionner le bouton « Afficher ».
// Écrivez votre code sous cette ligne.
