// Le fichier JavaScript est chargé après l'analyse de la page HTML.
// Complétez les étapes de la fiche d'activité sous ce commentaire.
