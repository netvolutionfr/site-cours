# Première NSI — lundi 12 octobre 2026
# 6. Défi : convertir par divisions
# Prolongement facultatif : écrire ecrire_binaire(n) pour un entier positif ou nul. La fonction renvoie du texte, sans préfixe 0b et sans zéros inutiles. N’utilisez ni bin ni format. Cet exercice est indépendant du précédent.
# Avant de lancer : prévoir le résultat ; après : expliquer une correction.
# Remplacez les ... ; ne modifiez pas les tests.

def ecrire_binaire(n):
    if n == 0:
        return ...
    bits = ""
    while n > 0:
        bits = ...
        n = ...
    return bits


print(ecrire_binaire(13))

# Tests : un assert silencieux a réussi.
assert ecrire_binaire(0) == "0"
assert ecrire_binaire(1) == "1"
assert ecrire_binaire(2) == "10"
assert ecrire_binaire(13) == "1101"
assert ecrire_binaire(57) == "111001"
assert ecrire_binaire(127) == "1111111"
assert ecrire_binaire(128) == "10000000"
assert ecrire_binaire(200) == "11001000"
assert ecrire_binaire(255) == "11111111"
assert ecrire_binaire(256) == "100000000"
assert ecrire_binaire(1000) == "1111101000"
print("Tous les tests passent.")
